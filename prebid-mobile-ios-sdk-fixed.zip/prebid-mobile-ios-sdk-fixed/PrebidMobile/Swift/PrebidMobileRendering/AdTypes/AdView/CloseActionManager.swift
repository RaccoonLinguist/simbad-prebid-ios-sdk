//
// Copyright 2018-2025 Prebid.org, Inc.

// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at

// http://www.apache.org/licenses/LICENSE-2.0

// Unless required by applicable law or agreed to in writing, software
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
    
enum CloseAction: Int {
    case closeButton
    case autoClose
    case unknown
}

struct CloseActionManager {
    static func getAction(from description: String) -> CloseAction {
        switch description.lowercased() {
        case "closebutton":
            return .closeButton
        case "autoclose":
            return .autoClose
        default:
            return .unknown
        }
    }
}
