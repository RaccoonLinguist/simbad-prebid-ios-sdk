/*   Copyright 2018-2021 Prebid.org, Inc.

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

 http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
 */

#import "PBMBidResponseTransformer.h"
#import "PBMORTBAbstract+Protected.h"

#import "SwiftImport.h"

@implementation PBMBidResponseTransformer

+ (BidResponse *)transformResponse:(PrebidServerResponse *)response error:(NSError **)error {
    NSString * const responseBody = [[NSString alloc] initWithData:response.rawData encoding:NSUTF8StringEncoding];
    
    if ([responseBody containsString:@"Invalid request"]) {
        if (error) {
            *error = [self classifyRequestError:responseBody];
        }
        return nil;
    }
    
    // ==========================================
    // ПАТЧ: Спасаем сломанный JSON от Xoalt
    // ==========================================
    NSDictionary *workingJsonDict = response.jsonDict;
    
    // Если оригинальный парсер сломался (jsonDict == nil), пытаемся вылечить сырые данные
    if (!workingJsonDict && response.rawData) {
        NSString *cleanString = [[NSString alloc] initWithData:response.rawData encoding:NSUTF8StringEncoding];
        if (cleanString) {
            // Удаляем BOM и заменяем все переносы и табы на пробелы
            cleanString = [cleanString stringByReplacingOccurrencesOfString:@"\uFEFF" withString:@""];
            cleanString = [cleanString stringByReplacingOccurrencesOfString:@"\n" withString:@" "];
            cleanString = [cleanString stringByReplacingOccurrencesOfString:@"\r" withString:@" "];
            cleanString = [cleanString stringByReplacingOccurrencesOfString:@"\t" withString:@" "];
            
            // =====================================
            // НОВАЯ СТРОКА: Указываем SDK, что это баннер, так как сервер забыл это сделать
            cleanString = [cleanString stringByReplacingOccurrencesOfString:@"\"prebid\":{\"targeting\"" withString:@"\"prebid\":{\"type\":\"banner\",\"targeting\""];
            // =====================================
            
            NSData *cleanData = [cleanString dataUsingEncoding:NSUTF8StringEncoding];
            NSError *jsonError = nil;
            // Парсим вылеченный JSON
            workingJsonDict = [NSJSONSerialization JSONObjectWithData:cleanData options:0 error:&jsonError];
            
            if (workingJsonDict) {
                NSLog(@"✅ ПАТЧ СРАБОТАЛ: JSON успешно восстановлен и очищен!");
            }
        }
    }
    // ==========================================
    
    if (!workingJsonDict) {
        if (error) {
            *error = [PBMError jsonDictNotFound];
        }
        return nil;
    }
    
    // Передаем наш спасенный workingJsonDict вместо сломанного response.jsonDict
    BidResponse * const bidResponse = [[BidResponse alloc] initWithJsonDictionary:workingJsonDict];
    
    if (!bidResponse) {
        if (error) {
            *error = [PBMError responseDeserializationFailed];
        }
        return nil;
    }
    
    if (error) {
        *error = nil;
    }
    
    return bidResponse;
}

+ (NSError *)classifyRequestError:(NSString *)responseBody {
    if ([responseBody containsString:@"Stored Imp with ID"] || [responseBody containsString:@"No stored imp found"]) {
        return [PBMError prebidInvalidConfigId];
    }
    if ([responseBody containsString:@"Stored Request with ID"] || [responseBody containsString:@"No stored request found"]) {
        return [PBMError prebidInvalidAccountId];
    }
    if ([responseBody containsString:@"Invalid request: Request imp[0].banner.format"] || [responseBody containsString:@"Request imp[0].banner.format"] || [responseBody containsString:@"Unable to set interstitial size list"]) {
        return [PBMError prebidInvalidSize];
    }
    return [PBMError serverError:responseBody];
}

@end
