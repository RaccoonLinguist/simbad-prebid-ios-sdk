/*   Copyright 2018-2021 Prebid.org, Inc.

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

 http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
 */

#import <StoreKit/SKStoreProductViewController.h>
#import <WebKit/WebKit.h>

#import "PBMAbstractCreative+Protected.h"
#import "PBMAbstractCreative.h"
#import "PBMSafariVCOpener.h"
#import "PBMDeepLinkPlusHelper.h"
#import "PBMFunctions+Private.h"
#import "PBMFunctions.h"
#import "PBMMacros.h"
#import "PBMModalState.h"
#import "PBMOpenMeasurementSession.h"
#import "PBMOpenMeasurementWrapper.h"
#import "PBMWindowLocker.h"

#import "Log+Extensions.h"

#import "SwiftImport.h"

@interface PBMAbstractCreative_Objc () <SKStoreProductViewControllerDelegate>

@property (nonatomic, weak, readwrite) id<PBMTransaction> transaction;
@property (nonatomic, strong, readwrite) PBMEventManager *eventManager;

@property (nonatomic, copy, nullable, readwrite) PBMVoidBlock dismissInterstitialModalState;
@property (nonatomic, copy, nullable) PBMVoidBlock skStoreProductViewControllerExitBlock;

@property (nonatomic, strong, nullable) id<PBMModalState> pendingModalStatePop;

@property (nonatomic, assign) BOOL adWasShown;

@property (nonatomic, strong, nullable) PBMSafariVCOpener * safariOpener;

@end

@implementation PBMAbstractCreative_Objc
@synthesize creativeModel = _creativeModel;
@synthesize creativeResolutionDelegate = _creativeResolutionDelegate;
@synthesize creativeViewDelegate = _creativeViewDelegate;
@synthesize clickthroughVisible = _clickthroughVisible;
@synthesize dispatchQueue = _dispatchQueue;
@synthesize isDownloaded = _isDownloaded;
@synthesize modalManager = _modalManager;
@synthesize skOverlayManager = _skOverlayManager;
@synthesize view = _view;
@synthesize viewControllerForPresentingModals = _viewControllerForPresentingModals;
@synthesize viewabilityTracker = _viewabilityTracker;

#pragma mark - Init

- (instancetype)initWithCreativeModel:(PBMCreativeModel *)creativeModel
                          transaction:(id<PBMTransaction>)transaction {
    self = [super init];
    if (self) {
        PBMAssert(creativeModel);
        
        _clickthroughVisible = NO;
        _isDownloaded = NO;
        _creativeModel = creativeModel;
        _transaction = transaction;
        _dispatchQueue = dispatch_queue_create("PBMAbstractCreative", NULL);
        _eventManager = [PBMEventManager new];
        
        if (creativeModel.eventTracker) {
            [self.eventManager registerTracker: (id<PBMEventTrackerProtocol>)creativeModel.eventTracker];
        } else {
            PBMLogError(@"Creative model must be provided with event tracker");
        }
        
        if(@available(iOS 14.5, *)) {
            if (self.transaction.bid.skadn) {
                SKAdImpression *imp = [PBMSkadnParametersManager getSkadnImpressionFor:self.transaction.bid.skadn];
                if (imp) {
                    PBMSkadnEventTracker *skadnTracker = [[PBMSkadnEventTracker alloc] initWith:imp];
                    [self.eventManager registerTracker:(id<PBMEventTrackerProtocol>) skadnTracker];
                }
            }
        }
        
        PrebidServerEventTracker *internalEventTracker = [[PrebidServerEventTracker alloc] initWithServerEvents:@[]];
        
        NSString *impURL = self.transaction.bid.events.imp;
        
        if (impURL) {
            PBMServerEvent *impEvent = [[PBMServerEvent alloc] initWithUrl:impURL expectedEventType:PBMTrackingEventImpression];
            [internalEventTracker addServerEvents:@[impEvent]];
        }
        
        NSString *winURL = self.transaction.bid.events.win;
        
        if (winURL) {
            PBMServerEvent *winEvent = [[PBMServerEvent alloc] initWithUrl:winURL expectedEventType:PBMTrackingEventPrebidWin];
            [internalEventTracker addServerEvents:@[winEvent]];
        }
        
        NSString * burl = self.transaction.bid.burl;
        
        if (burl) {
            PBMServerEvent *billingEvent = [[PBMServerEvent alloc] initWithUrl:burl expectedEventType:PBMTrackingEventImpression];
            [internalEventTracker addServerEvents:@[billingEvent]];
        }
        
        if (internalEventTracker.serverEvents.count > 0) {
            [self.eventManager registerTracker:(id<PBMEventTrackerProtocol>) internalEventTracker];
        }
        
        // Track win event immediately
        [self.eventManager trackEvent:PBMTrackingEventPrebidWin];
    }

    return self;
}

- (void)dealloc {
    [self.viewabilityTracker stop];
    
    if (self.skOverlayManager) {
        [self.skOverlayManager dismissSKOverlay];
        self.skOverlayManager = nil;
    }
    
    self.viewabilityTracker = NULL;
    PBMLogWhereAmI();
}

#pragma mark - Properties

- (BOOL)isOpened {
    return NO;
}

- (NSNumber *)displayInterval {
    return nil;
}

#pragma mark - Public

- (void)setupView {
    [self setupViewWithThread:NSThread.currentThread];
}

- (void)setupViewWithThread:(id<PBMThreadProtocol>)thread {
    if (!thread.isMainThread) {
        PBMLogError(@"Attempting to set up view on background thread");
    }
}

- (void)displayWithRootViewController:(UIViewController*)viewController {
    if (viewController == nil) {
        PBMLogError(@"viewController is nil");
        return;
    }
    
    self.viewControllerForPresentingModals = viewController;
    if (self.creativeModel.adConfiguration.isInterstitialAd) { // raw value access intended
        self.adWasShown = NO;
    }
    
    if (!self.adWasShown) {
        self.viewabilityTracker = [PBMFactory createCreativeViewabilityTrackerWithCreative:self];
    }
    
    PBMORTBBidExtSkadn * skadnInfo = self.transaction.bid.skadn;
    
    BOOL showSKOverlay = !self.creativeModel.hasCompanionAd &&
                         self.creativeModel.adConfiguration.isInterstitialAd &&
                         ((self.creativeModel.isCompanionAd && skadnInfo.skoverlay.endcarddelay != nil) ||
                         (!self.creativeModel.isCompanionAd && skadnInfo.skoverlay.delay != nil));
    
    if (showSKOverlay) {
        self.skOverlayManager = [[PBMSKOverlayManager alloc] initWithViewControllerForPresentation:self.viewControllerForPresentingModals];
        [self.skOverlayManager presentSKOverlayWith:skadnInfo isCompanionAd:self.creativeModel.isCompanionAd];
    }
}

- (void)showAsInterstitialFromRootViewController:(UIViewController*)uiViewController displayProperties:(PBMInterstitialDisplayProperties*)displayProperties {
    //This containerView will be stretched to fit the available screen.
    UIView *containerView = [[UIView alloc] initWithFrame:CGRectZero];
    [containerView addSubview:self.view];
    
    displayProperties.closeDelayLeft = displayProperties.closeDelay;
    
    //Create ModalState and push

    @weakify(self);
    id<PBMModalState> state = [PBMFactory createModalStateWithView:containerView
                                                   adConfiguration:self.creativeModel.adConfiguration
                                                 displayProperties:displayProperties
                                                onStatePopFinished:^(id<PBMModalState> _Nonnull poppedState) {
        @strongify(self);
        if (!self) { return; }

        if (self.skStoreProductViewControllerExitBlock) {
            self.pendingModalStatePop = poppedState;
        }

        [self modalManagerDidFinishPop:poppedState];
    } onStateHasLeftApp:^(id<PBMModalState> _Nonnull leavingState) {
        @strongify(self);
        if (!self) { return; }
        
        [self modalManagerDidLeaveApp:leavingState];
    } nextOnStatePopFinished:nil nextOnStateHasLeftApp:nil onModalPushedBlock:nil];
    
    self.dismissInterstitialModalState = [self.modalManager pushModal:state fromRootViewController:uiViewController animated:YES shouldReplace:NO completionHandler:^{
        [self displayWithRootViewController:uiViewController];
        [self.modalManager.modalViewController addFriendlyObstructionsToMeasurementSession:self.transaction.measurementSession];
    }];
}

- (void)handleClickthrough:(NSURL*)url {
    // Call overridden method with empty non-null closures
    [self handleClickthrough:url
            sdkConfiguration:Prebid.shared
           completionHandler:^(BOOL success){}
                      onExit:^{}];
}

- (void)handleClickthrough:(NSURL*)url
          sdkConfiguration:(Prebid *)sdkConfiguration {
    [self handleClickthrough:url
            sdkConfiguration:sdkConfiguration
           completionHandler:^(BOOL success){}
                      onExit:^{}];
}

- (void)handleClickthrough:(NSURL*)url
         completionHandler:(void (^)(BOOL success))completion
                    onExit:(PBMVoidBlock)onClickthroughExitBlock {
    [self handleClickthrough:url
            sdkConfiguration:Prebid.shared
           completionHandler:completion
                      onExit:onClickthroughExitBlock];
}

- (void)handleClickthrough:(NSURL*)url
          sdkConfiguration:(Prebid *)sdkConfiguration
         completionHandler:(void (^)(BOOL success))completion
                    onExit:(PBMVoidBlock)onClickthroughExitBlock {
    
    if (self.creativeModel.adConfiguration.clickHandlerOverride != nil) {
        completion(YES);
        self.creativeModel.adConfiguration.clickHandlerOverride(onClickthroughExitBlock);
        return;
    }
    BOOL clickthroughOpened = NO;
    PBMJsonDictionary * skadnetProductParameters;
    
    if (self.transaction.bid.skadn) {
        skadnetProductParameters = [PBMSkadnParametersManager
                                    getSkadnProductParametersFor:self.transaction.bid.skadn];
    }
    
    if (skadnetProductParameters) {
            clickthroughOpened = [self handleProductClickthrough:url
                                                   productParams:skadnetProductParameters
                                                          onExit:onClickthroughExitBlock];
    } else {
        
        if ([self handleDeepLinkIfNeeded:url
                        sdkConfiguration:sdkConfiguration
                       completionHandler:completion
                                  onExit:onClickthroughExitBlock]) {
            return;
        }
        
        clickthroughOpened = [self handleNormalClickthrough:url
                                           sdkConfiguration:sdkConfiguration
                                                     onExit:onClickthroughExitBlock];
    }
    
    completion(clickthroughOpened);

    if (!clickthroughOpened) {
        onClickthroughExitBlock();
    }
    return;
}

//checks the given URL and process it if it's a deep link
//return YES if the given URL is deeplink
- (BOOL)handleDeepLinkIfNeeded:(NSURL*)url
              sdkConfiguration:(Prebid *)sdkConfiguration
             completionHandler:(void (^)(BOOL success))completion
                        onExit:(PBMVoidBlock)onClickthroughExitBlock {
    NSURL *effectiveURL = url;
    if (self.creativeModel.targetURL != nil) {
        NSURL *overrideURL = [NSURL URLWithString:self.creativeModel.targetURL];
        if (overrideURL != nil) {
            effectiveURL = overrideURL;
        }
    }

    if (![PBMDeepLinkPlusHelper isDeepLinkPlusURL:effectiveURL]) {
        return NO;
    } else {
        @weakify(self);
        [PBMDeepLinkPlusHelper tryHandleDeepLinkPlus:effectiveURL completion:^(BOOL visited, NSURL *_Nullable fallbackURL, NSArray<NSURL *> *_Nullable trackingURLs) {
            @strongify(self);
            if (!self) { return; }
            
            if (visited) {
                completion(YES);
                onClickthroughExitBlock();
            } else if (!fallbackURL) {
                completion(NO);
                onClickthroughExitBlock();
            } else {
                BOOL clickthroughOpened = [self handleNormalClickthrough:fallbackURL
                                                        sdkConfiguration:sdkConfiguration
                                                                  onExit:onClickthroughExitBlock];

                completion(clickthroughOpened);

                if (clickthroughOpened) {
                    if (trackingURLs != nil) {
                        [PBMDeepLinkPlusHelper visitTrackingURLs:trackingURLs];
                    }
                } else {
                    onClickthroughExitBlock();
                }
            }
        }];
        return YES;
    }
}

//Returns true if the clickthrough is presented
- (BOOL)handleNormalClickthrough:(NSURL *)url
                sdkConfiguration:(Prebid *)sdkConfiguration
                          onExit:(nonnull PBMVoidBlock)onClickthroughExitBlock {
    
    @weakify(self);
    
    self.safariOpener = [[PBMSafariVCOpener alloc] initWithSDKConfiguration:sdkConfiguration
                                                                           modalManager:self.modalManager
                                                                 viewControllerProvider:^UIViewController * _Nullable{
        @strongify(self);
        return self.viewControllerForPresentingModals;
    } measurementSessionProvider: ^PBMOpenMeasurementSession * _Nullable{
        @strongify(self);
        return self.transaction.measurementSession;
    } onWillLoadURLInClickthrough:^{
        @strongify(self);
        self.clickthroughVisible = YES;
    } onWillLeaveAppBlock:^{
        @strongify(self);
        if (!self) { return; }
        
        [self.creativeViewDelegate creativeInterstitialDidLeaveApp:self];
    } onClickthroughPoppedBlock:^(id<PBMModalState> poppedState) {
        @strongify(self);
        if (!self) { return; }
        
        [self modalManagerDidFinishPop:poppedState];
    } onDidLeaveAppBlock:^(id<PBMModalState> leavingState) {
        @strongify(self);
        if (!self) { return; }
        
        [self modalManagerDidLeaveApp:leavingState];
    }];
    
    return [self.safariOpener openURL:url onClickthroughExitBlock:onClickthroughExitBlock];
}

- (BOOL)handleProductClickthrough:(NSURL*)url
                    productParams:(NSDictionary<NSString *, id> *)productParams
                           onExit:(nonnull PBMVoidBlock)onClickthroughExitBlock {
    PBMHiddenWebViewManager *webViewManager = [[PBMHiddenWebViewManager alloc] initWithFrame:self.view.frame
                                                                           landingPageString:url];
    [webViewManager openHiddenWebView];
    
    if (!self.viewControllerForPresentingModals) {
        PBMLogError(@"self.viewControllerForPresentingModals is nil");
        return NO;
    }
    
    if (@available(iOS 14, *)) {
        self.skStoreProductViewControllerExitBlock = onClickthroughExitBlock;

        dispatch_async(dispatch_get_main_queue(), ^{
            UIViewController *presentingController = self.viewControllerForPresentingModals;
            while (presentingController.presentedViewController) {
                presentingController = presentingController.presentedViewController;
            }

            SKStoreProductViewController *skadnController = [SKStoreProductViewController new];
            skadnController.delegate = self;
            self.clickthroughVisible = YES;
            [presentingController presentViewController:skadnController animated:YES completion:nil];
            [skadnController loadProductWithParameters:productParams completionBlock:^(BOOL result, NSError *error) {
                if (error) {
                    PBMLogError(@"Error presenting a product: %@", error.localizedDescription);
                }
            }];
        });
    }

    return YES;
}

// Helper methods for resolution success & failure
- (void)onResolutionCompleted {
    @weakify(self);
    dispatch_async(_dispatchQueue, ^{
        @strongify(self);
        if (!self) { return; }
        
        if (self.isDownloaded) {
            return;
        }

        self.isDownloaded = YES;
        
        [self.creativeResolutionDelegate creativeReady:self];
    });
}

- (void)onResolutionFailed:(nonnull NSError *)error {
    @weakify(self);
    dispatch_async(_dispatchQueue, ^{
        @strongify(self);
        if (!self) { return; }
        
        if (self.isDownloaded) {
            return;
        }
        
        self.isDownloaded = YES;
        [self.creativeResolutionDelegate creativeFailed:error];
    });
}

- (void)onViewabilityChanged:(BOOL)viewable viewExposure:(id<PBMViewExposure>)viewExposure {
    if (viewable && !self.adWasShown) {
        [self onAdDisplayed];
        self.adWasShown = YES;
    }
}

- (void)pause {
    // Implement in particular creatives
}

- (void)resume {
    // Implement in particular creatives
}

- (void)mute {
    // Implement in particular creatives
}

- (void)unmute {
    // Implement in particular creatives
}

- (BOOL)isMuted {
    return FALSE;
}

- (void)onWillTrackImpression {
    // Implement in particular creatives
}

#pragma mark - PBMModalManagerDelegate

- (void)modalManagerDidFinishPop:(id<PBMModalState>)state {
    PBMLogError(@"Abstract function called");
}

- (void)modalManagerDidLeaveApp:(id<PBMModalState>)state {
    PBMLogError(@"Abstract function called");
}

#pragma mark - SKStoreProductViewControllerDelegate

- (void)productViewControllerDidFinish:(SKStoreProductViewController *)viewController {
    id<PBMModalState> pendingStatePop = self.pendingModalStatePop;
    self.pendingModalStatePop = nil;

    if (self.clickthroughVisible) {
        self.clickthroughVisible = NO;
        [self.creativeViewDelegate creativeClickthroughDidClose:self];
    } else if (pendingStatePop) {
        [self modalManagerDidFinishPop:pendingStatePop];
    }

    if (self.skStoreProductViewControllerExitBlock) {
        self.skStoreProductViewControllerExitBlock();
        self.skStoreProductViewControllerExitBlock = nil;
    }
}

#pragma mark - Open Measurement

- (void)createOpenMeasurementSession {
    PBMLogError(@"Abstract function called");
}

- (void)onAdDisplayed {
    if (self.transaction.measurementSession.eventTracker) {
        [self.eventManager registerTracker:self.transaction.measurementSession.eventTracker];
    }
    [self.creativeViewDelegate creativeDidDisplay:self];
    [self onWillTrackImpression];
    [self.eventManager trackEvent:PBMTrackingEventImpression];
}

@end
